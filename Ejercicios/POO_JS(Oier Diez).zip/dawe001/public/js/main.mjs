import { tiposDeProductos, listaProductosPorTipo } from './tienda.mjs';
import Agricola from './agricola.mjs';
import Deportivo from './deportivo.mjs';
import Mueble from './mueble.mjs';

window.onload = () => {
    const contenedorProductosAgricolas = document.getElementById('productos-agricolas');
    const contenedorProductosDeportivos = document.getElementById('productos-deportivos');
    const contenedorMuebles = document.getElementById('muebles');

    const columnas = [contenedorProductosAgricolas, contenedorProductosDeportivos, contenedorMuebles];
    columnas.forEach((columna, index) => {
        const titulo = document.createElement('h2');
        titulo.textContent = tiposDeProductos[index];
        columna.appendChild(titulo);
    });
    
    function imprimirProductoHTML(producto) {
        let tipoProducto = '';
        if (producto instanceof Agricola) {
            tipoProducto = 'Origen:';
        } else if (producto instanceof Deportivo) {
            tipoProducto = 'Marca:';
        } else if (producto instanceof Mueble) {
            tipoProducto = 'Fabricante:';
        }
    
        return `
            <div class="producto">
                <div class="titulo">${producto.nombre}</div>
                <div><span>Precio:</span> ${producto.precio}€</div>
                <div><span>${tipoProducto}</span> ${producto.origen || producto.marca || producto.fabricante}</div>
            </div>
        `;
    }

    function renderizarProductos(contenedor, listaProductos) {
        listaProductos.forEach(producto => {
            contenedor.innerHTML += imprimirProductoHTML(producto);
        });
    }

    renderizarProductos(contenedorProductosAgricolas, listaProductosPorTipo[0], tiposDeProductos[0]);
    renderizarProductos(contenedorProductosDeportivos, listaProductosPorTipo[1], tiposDeProductos[1]);
    renderizarProductos(contenedorMuebles, listaProductosPorTipo[2], tiposDeProductos[2]);
};
